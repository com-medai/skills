# Metadata lookup API reference

All lookups are done with the assistant's **web fetch tool**, not shell curl/requests (the sandbox
proxy blocks scholarly APIs). Each endpoint below returns JSON on a plain GET — no custom headers
needed — which is why the fetch tool can retrieve them.

## Crossref REST (primary)

Single work by DOI:

```
https://api.crossref.org/works/{DOI}
```

Returns `{"status":"ok","message-type":"work","message":{ ...full record... }}`. Key fields in
`message`:

- `title` (array), `subtitle` (array)
- `author` (array of `{given, family, sequence}`) — `sequence` is `"first"` / `"additional"`,
  which preserves author order.
- `issued.date-parts` → `[[YYYY, M, D]]` (publication year). Fallbacks: `published`,
  `published-print`, `published-online`, `created`.
- `container-title` (array) — journal/proceedings/book title.
- `volume`, `issue`, `page` (e.g. `"436-444"`).
- `type` — `journal-article`, `posted-content` (preprint), `book`, `book-chapter`,
  `proceedings-article`, `dataset`, `report`, etc. `subtype` == `preprint` for preprints.
- `abstract` — sometimes present (JATS/HTML tagged); used for relevance grounding.
- `relation` — may contain `is-preprint-of` / `has-preprint` with related DOIs.
- `update-to` — retraction/correction notices point here; used for retraction flags.

Discovery search (for references with no DOI):

```
https://api.crossref.org/works?query.bibliographic={URL-ENCODED title + first author}&rows=3
```

Optionally narrow with `&query.author=Smith` or filter `&filter=from-pub-date:2015-01-01`. You can
trim the payload with `&select=DOI,title,author,issued,container-title,volume,issue,page,type`.
Response is `message-type: work-list` with `message.items` (array). Only accept a candidate if the
title and first author clearly match the reference — otherwise leave the reference unauditable.

**Etiquette / reliability:** append `&mailto=you@example.org` to requests to use Crossref's polite
pool. Keep request volume reasonable; if a fetch fails, retry once, then record it as not-checked
rather than blocking the whole run.

## DataCite REST (fallback for datasets / some books & DOIs not in Crossref)

```
https://api.datacite.org/dois/{DOI}
```

Returns `{"data":{"attributes":{...}}}` with `titles`, `creators` (`{givenName, familyName}`),
`publicationYear`, `publisher`, `container`, `descriptions` (abstract has
`descriptionType == "Abstract"`), and `types.resourceTypeGeneral`.

## DOI content negotiation (conceptual reference)

Per https://citation.doi.org/docs.html, `https://doi.org/{DOI}` with
`Accept: application/vnd.citationstyles.csl+json` returns CSL-JSON. This requires setting the Accept
header, which the fetch tool generally can't do, so prefer the Crossref/DataCite REST endpoints
above. `analyze_references.py` can still parse a bare CSL-JSON object if you manage to obtain one
(e.g. a 200 with `DOI`/`title` at top level).

## HTTP status meaning (from the DOI content-negotiation spec)

- `200` — OK, metadata returned.
- `204` — DOI exists but no metadata available.
- `404` — the DOI does not exist. Save `{"http_status":404,"not_found":true}` to the lookup file.
- `406` — content type not serveable (not relevant when using REST JSON).
