# references.json schema

The file you build in step 2 of the workflow. Either a bare list of reference objects, or an object
with `references`, `orphan_citations`, and `manuscript` keys (preferred, so hygiene checks work).

```json
{
  "manuscript": {
    "title": "Optional manuscript title (shown on the report cover)"
  },
  "orphan_citations": [
    "(Zhang & Kumar, 2019)",
    "[47]"
  ],
  "references": [
    {
      "id": "12",
      "raw_text": "Smith J, Doe A. A great title. J. Great Res. 2020;12(3):100-110. doi:10.1234/abcd",
      "type": "journal-article",
      "parsed": {
        "authors": ["Smith, J.", "Doe, A."],
        "year": "2020",
        "title": "A great title",
        "container_title": "Journal of Great Research",
        "volume": "12",
        "issue": "3",
        "pages": "100-110",
        "doi": "10.1234/abcd",
        "publisher": null
      },
      "in_text": {
        "citation_count": 2,
        "contexts": [
          "Prior work established the baseline effect in this population [12].",
          "As reported by Smith and Doe, the effect persists at 6 months [12]."
        ]
      },
      "relevance": null
    }
  ]
}
```

## Field notes

- **id** — must match the bibliography label and the `lookups/{id}.json` filename. For author–year
  styles use a stable slug like `Smith2020` or a running index; keep it consistent.
- **type** — one of: `journal-article`, `conference`, `book`, `chapter`, `report`, `thesis`,
  `dataset`, `preprint`, `website`, `other`. Drives whether an item is expected to be auditable.
- **parsed.authors** — ordered list, one string per author. Either "Family, Given" or
  "Given Family"; the analyzer extracts surnames and checks order either way.
- **parsed.doi** — bare DOI (`10.xxxx/...`) or a full URL; normalized downstream. `null` if none.
- **in_text.contexts** — the actual sentence(s) where the reference is cited. This is what the
  relevance score is judged against, so capture the claim, not just the citation marker.
- **in_text.citation_count** — total in-text uses. `0` triggers an "uncited reference" hygiene flag.
- **orphan_citations** (top level) — in-text markers with no matching bibliography entry.
- **relevance** — leave `null` when building; you fill it in during step 5. Shape:
  `{"score": 0-100, "rationale": "…"}`.
- **discovery_score** (optional) — if you did a no-DOI discovery search, you may record your
  confidence (0–100) that the discovered record matches; it is carried into the report.
```
