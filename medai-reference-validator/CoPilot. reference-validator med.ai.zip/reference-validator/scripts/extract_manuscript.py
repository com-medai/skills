#!/usr/bin/env python3
"""
extract_manuscript.py — Pull plain text out of a manuscript for reference parsing.

Supports .docx, .pdf, .txt, .md, .rtf (best-effort), .tex.
No network access required.

Usage:
    python extract_manuscript.py INPUT_FILE [-o OUTPUT.txt]

If -o is omitted, text is printed to stdout.

The goal is faithful text extraction (including the reference list and the body
so in-text citations can be located). It does NOT try to parse references — that
is done downstream by the model reading this text.
"""
import argparse
import os
import sys


def extract_docx(path: str) -> str:
    from docx import Document
    doc = Document(path)
    parts = []
    for para in doc.paragraphs:
        if para.text and para.text.strip():
            parts.append(para.text)
    # tables sometimes hold references or data
    for table in doc.tables:
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells if c.text and c.text.strip()]
            if cells:
                parts.append("\t".join(cells))
    return "\n".join(parts)


def extract_pdf(path: str) -> str:
    # Try pdfplumber first (best layout), fall back to pypdf.
    try:
        import pdfplumber
        out = []
        with pdfplumber.open(path) as pdf:
            for page in pdf.pages:
                t = page.extract_text() or ""
                out.append(t)
        text = "\n".join(out)
        if text.strip():
            return text
    except Exception:
        pass
    try:
        from pypdf import PdfReader
        reader = PdfReader(path)
        return "\n".join((p.extract_text() or "") for p in reader.pages)
    except Exception as e:
        print(f"ERROR: could not read PDF ({e})", file=sys.stderr)
        raise


def extract_plain(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("-o", "--output")
    args = ap.parse_args()

    ext = os.path.splitext(args.input)[1].lower()
    if ext == ".docx":
        text = extract_docx(args.input)
    elif ext == ".pdf":
        text = extract_pdf(args.input)
    elif ext in (".txt", ".md", ".tex", ".rtf"):
        text = extract_plain(args.input)
    else:
        # last resort: try as plain text
        text = extract_plain(args.input)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"Wrote {len(text)} chars to {args.output}", file=sys.stderr)
    else:
        sys.stdout.write(text)


if __name__ == "__main__":
    main()
