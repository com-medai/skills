#!/usr/bin/env python3
"""
analyze_references.py — Offline reference auditing engine.

Given (1) a references.json describing each reference as parsed from the
manuscript and (2) a folder of cached lookup responses (raw Crossref REST /
DataCite / CSL-JSON metadata fetched by the caller), this script:

  * normalizes the canonical online metadata,
  * compares every component field-by-field with fuzzy matching,
  * assigns per-field verdicts (Match / Partial / Mismatch / N/A) with scores,
  * derives an overall audit status per reference,
  * flags retractions and preprints (best-effort, from the metadata),
  * runs citation-hygiene checks (duplicates, uncited references),
  * computes the meta-analysis (including % unauditable / % no DOI),

and writes analysis.json. NO NETWORK is used here — all fetching happens
upstream via the caller's web fetch tool and is cached to disk.

Usage:
    python analyze_references.py references.json --lookups lookups/ -o analysis.json

references.json schema (list of objects):
{
  "id": "1",
  "raw_text": "Smith J, Doe A. Title. Journal. 2020;12(3):100-110. doi:10.x/y",
  "type": "journal-article",              # or book, chapter, conference, report, website, thesis, dataset, preprint, other
  "parsed": {
      "authors": ["Smith, J.", "Doe, A."],
      "year": "2020",
      "title": "….",
      "container_title": "Journal of X",
      "volume": "12", "issue": "3", "pages": "100-110",
      "doi": "10.x/y",                     # or null
      "publisher": null
  },
  "in_text": { "citation_count": 3, "contexts": ["…sentence…", "…"] }
}

Lookup cache: for reference with id "1", the file lookups/1.json holds the raw
JSON returned by the metadata service. The script auto-detects Crossref REST
(has "message"), DataCite ("data.attributes"), or bare CSL-JSON.

Optional top-level orphan citations (in-text markers with no matching entry)
can be supplied in references.json as {"references":[...], "orphan_citations":[...]}.
"""
import argparse
import json
import os
import re
import sys

try:
    from rapidfuzz import fuzz
    def ratio(a, b):
        return fuzz.token_sort_ratio(a, b)
    def plain_ratio(a, b):
        return fuzz.ratio(a, b)
except Exception:  # fallback to stdlib
    from difflib import SequenceMatcher
    def _sm(a, b):
        return SequenceMatcher(None, a, b).ratio() * 100
    def ratio(a, b):
        ta, tb = " ".join(sorted(a.split())), " ".join(sorted(b.split()))
        return _sm(ta, tb)
    def plain_ratio(a, b):
        return _sm(a, b)


# ----------------------------- normalization helpers -----------------------------

def norm_text(s):
    if not s:
        return ""
    s = str(s).lower()
    s = re.sub(r"<[^>]+>", " ", s)          # strip html/jats tags
    s = re.sub(r"[^a-z0-9 ]+", " ", s)      # drop punctuation
    s = re.sub(r"\s+", " ", s).strip()
    return s


def norm_doi(d):
    if not d:
        return None
    d = str(d).strip()
    d = re.sub(r"^https?://(dx\.)?doi\.org/", "", d, flags=re.I)
    d = re.sub(r"^doi:\s*", "", d, flags=re.I)
    return d.strip().lower() or None


def norm_pages(p):
    if not p:
        return ""
    p = str(p).lower().replace("–", "-").replace("—", "-")
    p = re.sub(r"pp?\.?", "", p)
    p = re.sub(r"\s+", "", p)
    return p


def surname(author_str):
    """Extract a best-guess surname from a free-form author string."""
    if not author_str:
        return ""
    a = author_str.strip()
    if "," in a:                     # "Smith, John A."
        return norm_text(a.split(",")[0])
    parts = a.split()
    if len(parts) == 1:
        return norm_text(parts[0])
    # "John A. Smith" -> last token that isn't an initial
    for tok in reversed(parts):
        if len(re.sub(r"[^A-Za-z]", "", tok)) > 1:
            return norm_text(tok)
    return norm_text(parts[-1])


# ----------------------------- canonical metadata extraction -----------------------------

def canonical_from_crossref(msg):
    def first(lst):
        return lst[0] if isinstance(lst, list) and lst else None
    authors = []
    for a in msg.get("author", []) or []:
        fam = a.get("family") or a.get("name") or ""
        authors.append({
            "family": fam,
            "given": a.get("given", ""),
            "sequence": a.get("sequence", ""),
        })
    year = None
    for key in ("issued", "published", "published-print", "published-online", "created"):
        dp = (msg.get(key) or {}).get("date-parts")
        if dp and dp[0] and dp[0][0]:
            year = str(dp[0][0])
            break
    relation = msg.get("relation", {}) or {}
    # retraction / preprint detection
    retracted = _detect_retraction(msg)
    preprint_of = None
    published_ver = None
    for rk, rv in relation.items():
        items = rv if isinstance(rv, list) else [rv]
        for it in items:
            rid = norm_doi(it.get("id")) if isinstance(it, dict) else None
            if "is-preprint-of" in rk and rid:
                published_ver = rid
            if "has-preprint" in rk and rid:
                preprint_of = rid
    subtype = msg.get("subtype", "")
    is_preprint = (msg.get("type") == "posted-content") or (subtype == "preprint")
    return {
        "source": "crossref",
        "title": first(msg.get("title") or []) or "",
        "subtitle": first(msg.get("subtitle") or []) or "",
        "authors": authors,
        "year": year,
        "container_title": first(msg.get("container-title") or []) or "",
        "volume": msg.get("volume", ""),
        "issue": msg.get("issue", ""),
        "page": msg.get("page", ""),
        "type": msg.get("type", ""),
        "publisher": msg.get("publisher", ""),
        "doi": norm_doi(msg.get("DOI")),
        "abstract": re.sub(r"<[^>]+>", " ", msg.get("abstract", "") or "").strip(),
        "is_preprint": is_preprint,
        "published_version_doi": published_ver,
        "preprint_doi": preprint_of,
        "retracted": retracted,
    }


def _detect_retraction(msg):
    # Crossref exposes retraction via update-to / relation / crossmark; best-effort.
    title = " ".join(msg.get("title") or []).lower()
    if "retracted" in title or "retraction" in title or "withdrawn" in title:
        return True
    for upd in msg.get("update-to", []) or []:
        if "retract" in str(upd.get("type", "")).lower():
            return True
    rel = msg.get("relation", {}) or {}
    for rk in rel:
        if "retract" in rk.lower():
            return True
    return False


def canonical_from_datacite(data):
    attr = data.get("data", {}).get("attributes", {}) if "data" in data else data.get("attributes", {})
    if not attr:
        return None
    authors = []
    for c in attr.get("creators", []) or []:
        authors.append({
            "family": c.get("familyName", "") or c.get("name", ""),
            "given": c.get("givenName", ""),
            "sequence": "",
        })
    titles = attr.get("titles", []) or []
    title = titles[0].get("title", "") if titles else ""
    year = str(attr.get("publicationYear", "") or "")
    return {
        "source": "datacite",
        "title": title, "subtitle": "", "authors": authors, "year": year or None,
        "container_title": (attr.get("container", {}) or {}).get("title", ""),
        "volume": (attr.get("container", {}) or {}).get("volume", ""),
        "issue": (attr.get("container", {}) or {}).get("issue", ""),
        "page": "", "type": (attr.get("types", {}) or {}).get("resourceTypeGeneral", ""),
        "publisher": attr.get("publisher", ""),
        "doi": norm_doi(attr.get("doi")),
        "abstract": next((d.get("description", "") for d in attr.get("descriptions", []) or []
                          if d.get("descriptionType") == "Abstract"), ""),
        "is_preprint": False, "published_version_doi": None, "preprint_doi": None,
        "retracted": False,
    }


def canonical_from_csl(obj):
    def dpy(o):
        dp = (o or {}).get("date-parts")
        return str(dp[0][0]) if dp and dp[0] and dp[0][0] else None
    authors = [{"family": a.get("family", ""), "given": a.get("given", ""), "sequence": ""}
               for a in obj.get("author", []) or []]
    return {
        "source": "csl", "title": obj.get("title", "") or "", "subtitle": "",
        "authors": authors, "year": dpy(obj.get("issued")),
        "container_title": obj.get("container-title", "") or "",
        "volume": obj.get("volume", ""), "issue": obj.get("issue", ""),
        "page": obj.get("page", ""), "type": obj.get("type", ""),
        "publisher": obj.get("publisher", ""), "doi": norm_doi(obj.get("DOI")),
        "abstract": obj.get("abstract", "") or "",
        "is_preprint": obj.get("type") == "article" and False,
        "published_version_doi": None, "preprint_doi": None, "retracted": False,
    }


def parse_lookup(raw):
    """Detect the metadata format and normalize."""
    if not isinstance(raw, dict):
        return None
    if "message" in raw and isinstance(raw["message"], dict):
        # could be a Crossref /works/{doi} (message-type work) or a query (message.items)
        m = raw["message"]
        if raw.get("message-type") == "work-list" or "items" in m:
            items = m.get("items", [])
            return canonical_from_crossref(items[0]) if items else None
        return canonical_from_crossref(m)
    if "data" in raw and isinstance(raw["data"], dict) and "attributes" in raw["data"]:
        return canonical_from_datacite(raw)
    if "attributes" in raw:
        return canonical_from_datacite(raw)
    if "DOI" in raw or "title" in raw:
        return canonical_from_csl(raw)
    return None


# ----------------------------- field matching -----------------------------

def verdict_from_score(score, hi=90, mid=75):
    if score >= hi:
        return "Match"
    if score >= mid:
        return "Partial"
    return "Mismatch"


def match_title(parsed, canon):
    pt = norm_text(parsed.get("title"))
    ct = norm_text((canon.get("title", "") + " " + canon.get("subtitle", "")).strip())
    if not pt or not ct:
        return {"field": "title", "verdict": "N/A", "score": None,
                "reference_value": parsed.get("title", ""), "online_value": canon.get("title", "")}
    s = round(ratio(pt, ct))
    # also try without subtitle
    s = max(s, round(ratio(pt, norm_text(canon.get("title", "")))))
    return {"field": "title", "verdict": verdict_from_score(s, 92, 78), "score": s,
            "reference_value": parsed.get("title", ""), "online_value": canon.get("title", "")}


def match_authors(parsed, canon):
    p_auth = parsed.get("authors") or []
    c_auth = canon.get("authors") or []
    p_sur = [surname(a) for a in p_auth if surname(a)]
    c_sur = [norm_text(a.get("family", "")) for a in c_auth if a.get("family")]
    online_str = "; ".join(f"{a.get('family','')} {a.get('given','')}".strip() for a in c_auth)
    ref_str = "; ".join(p_auth)
    if not p_sur or not c_sur:
        return {"field": "authors", "verdict": "N/A", "score": None, "order_ok": None,
                "reference_value": ref_str, "online_value": online_str,
                "note": "insufficient author data to compare"}
    # membership: how many reference surnames appear among canonical
    matched = 0
    for ps in p_sur:
        if any(plain_ratio(ps, cs) >= 88 for cs in c_sur):
            matched += 1
    coverage = matched / max(len(p_sur), 1)
    # order check: compare the ordered surname sequences
    n = min(len(p_sur), len(c_sur))
    order_hits = sum(1 for i in range(n) if plain_ratio(p_sur[i], c_sur[i]) >= 88)
    order_ok = (n > 0 and order_hits == n and len(p_sur) <= len(c_sur) + 0) or (order_hits / max(n, 1) >= 0.9)
    count_ok = abs(len(p_sur) - len(c_sur)) <= 1
    score = round(100 * coverage)
    if coverage >= 0.99 and order_ok and count_ok:
        verdict = "Match"
    elif coverage >= 0.6:
        verdict = "Partial"
    else:
        verdict = "Mismatch"
    note = []
    if not order_ok:
        note.append("author order differs")
    if not count_ok:
        note.append(f"author count differs (ref {len(p_sur)} vs online {len(c_sur)})")
    return {"field": "authors", "verdict": verdict, "score": score, "order_ok": bool(order_ok),
            "reference_value": ref_str, "online_value": online_str,
            "note": "; ".join(note)}


def match_exact(field, pval, cval, allow_off_by_one=False):
    p = norm_text(pval) if field != "pages" else norm_pages(pval)
    c = norm_text(cval) if field != "pages" else norm_pages(cval)
    out = {"field": field, "reference_value": str(pval or ""), "online_value": str(cval or "")}
    if not p or not c:
        out.update({"verdict": "N/A", "score": None})
        return out
    if p == c:
        out.update({"verdict": "Match", "score": 100})
        return out
    if field == "year" and allow_off_by_one:
        try:
            if abs(int(re.sub(r"\D", "", p)) - int(re.sub(r"\D", "", c))) == 1:
                out.update({"verdict": "Partial", "score": 85,
                            "note": "off by one year (online-first vs print)"})
                return out
        except ValueError:
            pass
    if field == "pages":
        # first page match -> Partial
        pf = re.split(r"-", p)[0]
        cf = re.split(r"-", c)[0]
        if pf and pf == cf:
            out.update({"verdict": "Partial", "score": 80, "note": "start page matches, range differs"})
            return out
    s = round(plain_ratio(p, c))
    out.update({"verdict": verdict_from_score(s, 97, 85), "score": s})
    return out


# ----------------------------- per-reference audit -----------------------------

FIELD_WEIGHTS = {"title": 0.40, "authors": 0.25, "year": 0.10,
                 "container_title": 0.12, "volume": 0.05, "issue": 0.03, "pages": 0.05}
VERDICT_SCORE = {"Match": 1.0, "Partial": 0.6, "Mismatch": 0.0, "N/A": None}


def audit_reference(ref, lookups_dir):
    rid = str(ref.get("id"))
    parsed = ref.get("parsed", {}) or {}
    ref_doi = norm_doi(parsed.get("doi"))
    result = {
        "id": rid,
        "raw_text": ref.get("raw_text", ""),
        "type": ref.get("type", "other"),
        "parsed": parsed,
        "in_text": ref.get("in_text", {}),
        "doi_in_reference": ref_doi,
        "doi_source": None,          # reference | discovered | none
        "doi_exists": None,          # True / False / None (not checked)
        "http_status": None,
        "queried_doi": None,
        "discovery_score": ref.get("discovery_score"),
        "canonical": None,
        "field_matches": [],
        "field_match_confidence": None,
        "flags": [],
        "audit_status": None,
        "relevance": ref.get("relevance"),   # may be filled in by caller
    }

    # load cached lookup
    raw = None
    for cand in (rid, rid.replace("/", "_")):
        path = os.path.join(lookups_dir, f"{cand}.json") if lookups_dir else None
        if path and os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                if content:
                    raw = json.loads(content)
            except Exception as e:
                result["flags"].append(f"lookup parse error: {e}")
            break

    canon = parse_lookup(raw) if raw else None
    # explicit not-found marker: caller can write {"http_status":404} or {"not_found":true}
    if raw and (raw.get("http_status") == 404 or raw.get("not_found")):
        result["http_status"] = 404
    if raw and raw.get("http_status"):
        result["http_status"] = raw.get("http_status")
    if raw and raw.get("doi_source"):
        result["doi_source"] = raw.get("doi_source")

    if canon:
        result["canonical"] = canon
        result["queried_doi"] = canon.get("doi") or ref_doi
        result["doi_exists"] = True
        if result["http_status"] is None:
            result["http_status"] = 200
        if not result["doi_source"]:
            if ref_doi and canon.get("doi") and norm_doi(canon["doi"]) == ref_doi:
                result["doi_source"] = "reference"
            elif not ref_doi:
                result["doi_source"] = "discovered"
            else:
                result["doi_source"] = "reference"
    else:
        result["queried_doi"] = ref_doi
        if ref_doi and result["http_status"] == 404:
            result["doi_exists"] = False
            result["doi_source"] = "reference"
        elif not ref_doi:
            result["doi_source"] = "none"

    # field matching (only if we have canonical metadata)
    if canon:
        matches = [
            match_title(parsed, canon),
            match_authors(parsed, canon),
            match_exact("year", parsed.get("year"), canon.get("year"), allow_off_by_one=True),
            match_exact("container_title", parsed.get("container_title"), canon.get("container_title")),
            match_exact("volume", parsed.get("volume"), canon.get("volume")),
            match_exact("issue", parsed.get("issue"), canon.get("issue")),
            match_exact("pages", parsed.get("pages"), canon.get("page")),
        ]
        result["field_matches"] = matches
        # weighted confidence over fields that were comparable
        num = den = 0.0
        for m in matches:
            vs = VERDICT_SCORE.get(m["verdict"])
            if vs is None:
                continue
            w = FIELD_WEIGHTS.get(m["field"], 0.05)
            num += w * vs
            den += w
        result["field_match_confidence"] = round(100 * num / den) if den else None

        # flags
        if canon.get("retracted"):
            result["flags"].append("RETRACTED — cited work appears to be retracted/withdrawn")
        if canon.get("is_preprint") and canon.get("published_version_doi"):
            result["flags"].append(
                f"PREPRINT — a peer-reviewed version exists: {canon['published_version_doi']}")
        elif canon.get("is_preprint"):
            result["flags"].append("PREPRINT — cited work is an unrefereed preprint")
        if result["doi_source"] == "discovered":
            result["flags"].append(
                f"MISSING DOI — reference has no DOI; a matching DOI was found online: {result['queried_doi']}")
        # per-field problems
        for m in matches:
            if m["verdict"] == "Mismatch":
                result["flags"].append(f"{m['field']} mismatch")

    # audit status
    t = result["type"]
    non_auditable_types = {"book", "chapter", "report", "website", "thesis", "other", "conference"}
    if canon:
        conf = result["field_match_confidence"] or 0
        has_mismatch = any(m["verdict"] == "Mismatch" for m in result["field_matches"])
        if conf >= 85 and not has_mismatch:
            result["audit_status"] = "verified"
        elif conf >= 60:
            result["audit_status"] = "minor_discrepancy"
        else:
            result["audit_status"] = "mismatch"
    elif ref_doi and result["doi_exists"] is False:
        result["audit_status"] = "doi_not_found"
        result["flags"].append("DOI does not resolve (404)")
    elif ref_doi and result["http_status"] is None:
        result["audit_status"] = "not_checked"
    else:
        # no DOI at all
        result["audit_status"] = "unauditable_no_doi"
        if t in non_auditable_types:
            result["flags"].append(f"Not auditable online (type: {t}); components broken down only")
        else:
            result["flags"].append("No DOI present and none found online; not auditable")

    return result


# ----------------------------- hygiene + meta-analysis -----------------------------

def hygiene_checks(audited, orphan_citations):
    issues = []
    # duplicates by DOI
    seen_doi, seen_title = {}, {}
    for r in audited:
        d = r.get("queried_doi") or r.get("doi_in_reference")
        if d:
            seen_doi.setdefault(d, []).append(r["id"])
        t = norm_text((r.get("parsed") or {}).get("title"))
        if t and len(t) > 10:
            seen_title.setdefault(t, []).append(r["id"])
    for d, ids in seen_doi.items():
        if len(ids) > 1:
            issues.append({"type": "duplicate_doi", "detail": f"DOI {d} used by references {', '.join(ids)}",
                           "ids": ids})
    for t, ids in seen_title.items():
        if len(ids) > 1:
            issues.append({"type": "duplicate_title", "detail": f"Near-identical title in references {', '.join(ids)}",
                           "ids": ids})
    # uncited references
    for r in audited:
        cc = (r.get("in_text") or {}).get("citation_count")
        if cc == 0:
            issues.append({"type": "uncited_reference",
                           "detail": f"Reference {r['id']} never cited in the text", "ids": [r["id"]]})
    # orphan in-text citations
    for oc in orphan_citations or []:
        issues.append({"type": "orphan_citation",
                       "detail": f"In-text citation with no matching reference entry: {oc}", "ids": []})
    return issues


def meta_analysis(audited, issues):
    n = len(audited)
    def pct(x):
        return round(100 * x / n, 1) if n else 0.0
    have_doi = [r for r in audited if r.get("doi_in_reference")]
    no_doi = [r for r in audited if not r.get("doi_in_reference")]
    discovered = [r for r in audited if r.get("doi_source") == "discovered"]
    checked = [r for r in audited if r.get("doi_exists") is not None]
    doi_valid = [r for r in checked if r.get("doi_exists")]
    doi_broken = [r for r in checked if r.get("doi_exists") is False]
    unauditable = [r for r in audited if r.get("audit_status") == "unauditable_no_doi"
                   and r.get("doi_source") != "discovered"]
    verified = [r for r in audited if r.get("audit_status") == "verified"]
    minor = [r for r in audited if r.get("audit_status") == "minor_discrepancy"]
    mismatch = [r for r in audited if r.get("audit_status") == "mismatch"]
    with_meta_mismatch = [r for r in audited
                          if any(m["verdict"] == "Mismatch" for m in r.get("field_matches", []))]
    retracted = [r for r in audited if any("RETRACTED" in f for f in r.get("flags", []))]
    preprints = [r for r in audited if any(f.startswith("PREPRINT") for f in r.get("flags", []))]
    rel_scores = [r["relevance"]["score"] for r in audited
                  if isinstance(r.get("relevance"), dict) and r["relevance"].get("score") is not None]
    low_rel = [s for s in rel_scores if s < 50]

    by_type = {}
    for r in audited:
        by_type[r["type"]] = by_type.get(r["type"], 0) + 1

    return {
        "total_references": n,
        "references_with_doi": len(have_doi),
        "pct_with_doi": pct(len(have_doi)),
        "references_without_doi": len(no_doi),
        "pct_without_doi": pct(len(no_doi)),
        "pct_unauditable_no_doi": pct(len(unauditable)),
        "doi_discovered_count": len(discovered),
        "doi_checked": len(checked),
        "doi_valid": len(doi_valid),
        "doi_broken": len(doi_broken),
        "pct_doi_broken_of_checked": round(100 * len(doi_broken) / len(checked), 1) if checked else 0.0,
        "verified_count": len(verified),
        "pct_verified": pct(len(verified)),
        "minor_discrepancy_count": len(minor),
        "mismatch_count": len(mismatch),
        "references_with_metadata_mismatch": len(with_meta_mismatch),
        "pct_with_metadata_mismatch": pct(len(with_meta_mismatch)),
        "retracted_count": len(retracted),
        "preprint_count": len(preprints),
        "relevance_scored": len(rel_scores),
        "mean_relevance": round(sum(rel_scores) / len(rel_scores), 1) if rel_scores else None,
        "low_relevance_count": len(low_rel),
        "hygiene_issue_count": len(issues),
        "by_type": by_type,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("references")
    ap.add_argument("--lookups", default=None, help="folder of cached lookup JSON files")
    ap.add_argument("-o", "--output", default="analysis.json")
    args = ap.parse_args()

    with open(args.references, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, dict):
        refs = data.get("references", [])
        orphans = data.get("orphan_citations", [])
        meta_in = data.get("manuscript", {})
    else:
        refs, orphans, meta_in = data, [], {}

    audited = [audit_reference(r, args.lookups) for r in refs]
    issues = hygiene_checks(audited, orphans)
    meta = meta_analysis(audited, issues)

    out = {"manuscript": meta_in, "meta_analysis": meta,
           "hygiene_issues": issues, "references": audited}
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print(f"Analyzed {len(audited)} references -> {args.output}", file=sys.stderr)
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
