#!/usr/bin/env python3
"""
build_reports.py — Render analysis.json into a Word report and an Excel workbook.

Usage:
    python build_reports.py analysis.json --outdir OUT [--basename reference_audit]

Produces:
    OUT/<basename>.docx   full narrative report with charts + per-reference detail
    OUT/<basename>.xlsx   structured data: Summary, References, FieldMatches, Issues, Unauditable

No network. Requires python-docx, openpyxl, matplotlib.
"""
import argparse
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


STATUS_LABEL = {
    "verified": "VERIFIED",
    "minor_discrepancy": "MINOR DISCREPANCY",
    "mismatch": "MISMATCH",
    "doi_not_found": "DOI NOT FOUND",
    "unauditable_no_doi": "UNAUDITABLE (NO DOI)",
    "not_checked": "NOT CHECKED",
}
STATUS_HEX = {
    "verified": "2E7D32",
    "minor_discrepancy": "F9A825",
    "mismatch": "C62828",
    "doi_not_found": "C62828",
    "unauditable_no_doi": "757575",
    "not_checked": "9E9E9E",
}
VERDICT_HEX = {"Match": "2E7D32", "Partial": "F9A825", "Mismatch": "C62828", "N/A": "9E9E9E"}


# ----------------------------- charts -----------------------------

def make_charts(analysis, chart_dir):
    os.makedirs(chart_dir, exist_ok=True)
    meta = analysis["meta_analysis"]
    paths = {}

    # 1) audit status distribution
    counts = {}
    for r in analysis["references"]:
        counts[r["audit_status"]] = counts.get(r["audit_status"], 0) + 1
    if counts:
        labels = [STATUS_LABEL.get(k, k) for k in counts]
        vals = list(counts.values())
        colors = ["#" + STATUS_HEX.get(k, "607D8B") for k in counts]
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.bar(labels, vals, color=colors)
        ax.set_title("References by audit status")
        ax.set_ylabel("count")
        plt.xticks(rotation=25, ha="right", fontsize=8)
        plt.tight_layout()
        p = os.path.join(chart_dir, "status.png")
        fig.savefig(p, dpi=150); plt.close(fig); paths["status"] = p

    # 2) DOI coverage donut
    with_doi = meta["references_with_doi"]
    without = meta["references_without_doi"]
    if with_doi + without > 0:
        fig, ax = plt.subplots(figsize=(4.5, 4))
        ax.pie([with_doi, without], labels=["Has DOI", "No DOI"],
               autopct=lambda p: f"{p:.0f}%", colors=["#1565C0", "#B0BEC5"],
               wedgeprops=dict(width=0.42))
        ax.set_title("DOI coverage")
        p = os.path.join(chart_dir, "doi.png")
        fig.savefig(p, dpi=150); plt.close(fig); paths["doi"] = p

    # 3) relevance histogram
    rel = [r["relevance"]["score"] for r in analysis["references"]
           if isinstance(r.get("relevance"), dict) and r["relevance"].get("score") is not None]
    if rel:
        fig, ax = plt.subplots(figsize=(6, 3.5))
        ax.hist(rel, bins=[0, 20, 40, 60, 80, 100], color="#5E35B1", edgecolor="white")
        ax.set_title("Citation relevance confidence (AI-assessed)")
        ax.set_xlabel("relevance %"); ax.set_ylabel("count")
        plt.tight_layout()
        p = os.path.join(chart_dir, "relevance.png")
        fig.savefig(p, dpi=150); plt.close(fig); paths["relevance"] = p

    return paths


# ----------------------------- Word report -----------------------------

def _shade_cell(cell, hex_color):
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto"); shd.set(qn("w:fill"), hex_color)
    tcPr.append(shd)


def build_docx(analysis, out_path, chart_paths):
    meta = analysis["meta_analysis"]
    doc = Document()
    styles = doc.styles["Normal"]
    styles.font.name = "Calibri"; styles.font.size = Pt(10.5)

    title = doc.add_heading("Reference Validation Report", level=0)
    ms = analysis.get("manuscript", {})
    if ms.get("title"):
        doc.add_paragraph(ms["title"]).italic = True
    sub = doc.add_paragraph()
    sub.add_run(f"Total references analyzed: {meta['total_references']}").bold = True

    # Executive summary
    doc.add_heading("Executive Summary", level=1)
    verified_pct = round(100 * meta["verified_count"] / meta["total_references"], 1) if meta["total_references"] else 0
    summary = (
        f"Of {meta['total_references']} references, {meta['verified_count']} ({verified_pct}%) were fully "
        f"verified against online metadata. {meta['references_with_doi']} references "
        f"({meta['pct_with_doi']}%) carried a DOI; {meta['references_without_doi']} "
        f"({meta['pct_without_doi']}%) did not. {meta['pct_unauditable_no_doi']}% of all references "
        f"could not be audited online because they lacked a DOI and no match was found. "
        f"{meta['doi_broken']} DOI(s) failed to resolve, and {meta['references_with_metadata_mismatch']} "
        f"reference(s) had at least one metadata field that did not match the online record."
    )
    doc.add_paragraph(summary)

    # key alarms
    alarms = []
    if meta.get("retracted_count"):
        alarms.append(f"{meta['retracted_count']} reference(s) appear to cite RETRACTED work")
    if meta.get("doi_broken"):
        alarms.append(f"{meta['doi_broken']} DOI(s) do not resolve")
    if meta.get("preprint_count"):
        alarms.append(f"{meta['preprint_count']} preprint citation(s) detected")
    if meta.get("low_relevance_count"):
        alarms.append(f"{meta['low_relevance_count']} citation(s) scored low on relevance (<50%)")
    if meta.get("hygiene_issue_count"):
        alarms.append(f"{meta['hygiene_issue_count']} citation-hygiene issue(s)")
    if alarms:
        p = doc.add_paragraph()
        p.add_run("Items needing attention: ").bold = True
        p.add_run("; ".join(alarms) + ".")

    note = doc.add_paragraph()
    r = note.add_run("Note: Relevance confidence scores are AI-assessed judgments of how well each cited "
                     "work supports the claim at its citation location. They are advisory and should be "
                     "spot-checked, not treated as ground truth.")
    r.italic = True; r.font.size = Pt(9); r.font.color.rgb = RGBColor(0x60, 0x60, 0x60)

    # Meta-analysis metrics table
    doc.add_heading("Meta-Analysis", level=1)
    metrics = [
        ("Total references", meta["total_references"]),
        ("With DOI", f"{meta['references_with_doi']} ({meta['pct_with_doi']}%)"),
        ("Without DOI", f"{meta['references_without_doi']} ({meta['pct_without_doi']}%)"),
        ("Unauditable — no DOI found", f"{meta['pct_unauditable_no_doi']}%"),
        ("DOIs found online for no-DOI refs", meta["doi_discovered_count"]),
        ("DOIs checked", meta["doi_checked"]),
        ("DOIs valid", meta["doi_valid"]),
        ("DOIs broken (404)", f"{meta['doi_broken']} ({meta['pct_doi_broken_of_checked']}% of checked)"),
        ("Fully verified", f"{meta['verified_count']} ({meta['pct_verified']}%)"),
        ("Minor discrepancy", meta["minor_discrepancy_count"]),
        ("Mismatch", meta["mismatch_count"]),
        ("With ≥1 metadata mismatch", f"{meta['references_with_metadata_mismatch']} ({meta['pct_with_metadata_mismatch']}%)"),
        ("Retracted cited works", meta["retracted_count"]),
        ("Preprints", meta["preprint_count"]),
        ("Mean relevance (AI)", meta["mean_relevance"] if meta["mean_relevance"] is not None else "—"),
        ("Low-relevance citations (<50%)", meta["low_relevance_count"]),
    ]
    t = doc.add_table(rows=0, cols=2); t.style = "Light Grid Accent 1"
    for k, v in metrics:
        row = t.add_row().cells
        row[0].text = k; row[1].text = str(v)
        row[0].paragraphs[0].runs[0].bold = True

    for key in ("status", "doi", "relevance"):
        if chart_paths.get(key):
            doc.add_picture(chart_paths[key], width=Inches(5.2))
            doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER

    # reference types
    if meta.get("by_type"):
        doc.add_heading("Reference types", level=2)
        bt = doc.add_table(rows=1, cols=2); bt.style = "Light List Accent 1"
        bt.rows[0].cells[0].text = "Type"; bt.rows[0].cells[1].text = "Count"
        for k, v in sorted(meta["by_type"].items(), key=lambda x: -x[1]):
            c = bt.add_row().cells; c[0].text = k; c[1].text = str(v)

    # hygiene issues
    issues = analysis.get("hygiene_issues", [])
    if issues:
        doc.add_heading("Citation Hygiene Issues", level=1)
        it = doc.add_table(rows=1, cols=2); it.style = "Light Grid Accent 2"
        it.rows[0].cells[0].text = "Type"; it.rows[0].cells[1].text = "Detail"
        for iss in issues:
            c = it.add_row().cells
            c[0].text = iss["type"]; c[1].text = iss["detail"]

    # per-reference detail
    doc.add_heading("Per-Reference Detail", level=1)
    for r in analysis["references"]:
        status = r["audit_status"]
        h = doc.add_heading(level=2)
        run = h.add_run(f"[{r['id']}] {STATUS_LABEL.get(status, status)}")
        run.font.color.rgb = RGBColor.from_string(STATUS_HEX.get(status, "000000"))

        doc.add_paragraph(r.get("raw_text", "")).italic = True

        # id line
        line = doc.add_paragraph()
        doi = r.get("queried_doi") or r.get("doi_in_reference") or "—"
        line.add_run(f"DOI: {doi}   |   Source: {r.get('doi_source')}   |   Type: {r.get('type')}")
        if r.get("field_match_confidence") is not None:
            line.add_run(f"   |   Metadata match: {r['field_match_confidence']}%")

        # relevance
        rel = r.get("relevance")
        if isinstance(rel, dict) and rel.get("score") is not None:
            rp = doc.add_paragraph()
            rp.add_run(f"Citation relevance (AI): {rel['score']}%  ").bold = True
            if rel.get("rationale"):
                em = rp.add_run(rel["rationale"]); em.italic = True

        # flags
        if r.get("flags"):
            fp = doc.add_paragraph()
            fp.add_run("Flags: ").bold = True
            fp.add_run("; ".join(r["flags"]))

        # field comparison table
        if r.get("field_matches"):
            ft = doc.add_table(rows=1, cols=5); ft.style = "Light Grid"
            hdr = ft.rows[0].cells
            for i, htxt in enumerate(["Field", "In reference", "Online (DOI)", "Verdict", "Score"]):
                hdr[i].text = htxt; hdr[i].paragraphs[0].runs[0].bold = True
            for m in r["field_matches"]:
                c = ft.add_row().cells
                c[0].text = m["field"]
                c[1].text = str(m.get("reference_value", ""))[:300]
                c[2].text = str(m.get("online_value", ""))[:300]
                c[3].text = m["verdict"]
                c[4].text = "" if m.get("score") is None else str(m["score"])
                _shade_cell(c[3], VERDICT_HEX.get(m["verdict"], "FFFFFF"))
                if m["verdict"] != "N/A":
                    c[3].paragraphs[0].runs[0].font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        else:
            # unauditable: show parsed breakdown so it is still documented
            p = r.get("parsed", {})
            bt = doc.add_table(rows=1, cols=2); bt.style = "Light List"
            bt.rows[0].cells[0].text = "Component"; bt.rows[0].cells[1].text = "Value (as written)"
            for label, key in [("Authors", "authors"), ("Year", "year"), ("Title", "title"),
                               ("Source/Journal", "container_title"), ("Volume", "volume"),
                               ("Issue", "issue"), ("Pages", "pages"), ("Publisher", "publisher")]:
                val = p.get(key)
                if isinstance(val, list):
                    val = "; ".join(val)
                c = bt.add_row().cells; c[0].text = label; c[1].text = str(val or "—")

    doc.save(out_path)


# ----------------------------- Excel workbook -----------------------------

HDR_FILL = PatternFill("solid", fgColor="1F4E79")
HDR_FONT = Font(color="FFFFFF", bold=True)
THIN = Side(style="thin", color="D9D9D9")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
VERDICT_FILL = {"Match": "C6EFCE", "Partial": "FFEB9C", "Mismatch": "FFC7CE", "N/A": "EDEDED"}
STATUS_FILL = {"verified": "C6EFCE", "minor_discrepancy": "FFEB9C", "mismatch": "FFC7CE",
               "doi_not_found": "FFC7CE", "unauditable_no_doi": "EDEDED", "not_checked": "EDEDED"}


def _style_header(ws, ncols):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=1, column=c)
        cell.fill = HDR_FILL; cell.font = HDR_FONT
        cell.alignment = Alignment(vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"


def _autosize(ws, max_w=60):
    for col in ws.columns:
        length = max((len(str(c.value)) for c in col if c.value is not None), default=8)
        ws.column_dimensions[get_column_letter(col[0].column)].width = min(max(10, length + 2), max_w)


def build_xlsx(analysis, out_path):
    wb = Workbook()
    meta = analysis["meta_analysis"]

    # Summary
    ws = wb.active; ws.title = "Summary"
    ws.append(["Metric", "Value"]); _style_header(ws, 2)
    rows = [
        ("Total references", meta["total_references"]),
        ("With DOI", meta["references_with_doi"]),
        ("% with DOI", meta["pct_with_doi"]),
        ("Without DOI", meta["references_without_doi"]),
        ("% without DOI", meta["pct_without_doi"]),
        ("% unauditable (no DOI found)", meta["pct_unauditable_no_doi"]),
        ("DOIs discovered for no-DOI refs", meta["doi_discovered_count"]),
        ("DOIs checked", meta["doi_checked"]),
        ("DOIs valid", meta["doi_valid"]),
        ("DOIs broken (404)", meta["doi_broken"]),
        ("% DOIs broken (of checked)", meta["pct_doi_broken_of_checked"]),
        ("Fully verified", meta["verified_count"]),
        ("% verified", meta["pct_verified"]),
        ("Minor discrepancy", meta["minor_discrepancy_count"]),
        ("Mismatch", meta["mismatch_count"]),
        ("With >=1 metadata mismatch", meta["references_with_metadata_mismatch"]),
        ("% with metadata mismatch", meta["pct_with_metadata_mismatch"]),
        ("Retracted cited works", meta["retracted_count"]),
        ("Preprints", meta["preprint_count"]),
        ("Mean relevance (AI)", meta["mean_relevance"]),
        ("Low-relevance citations (<50%)", meta["low_relevance_count"]),
        ("Hygiene issues", meta["hygiene_issue_count"]),
    ]
    for k, v in rows:
        ws.append([k, v])
    for r in range(2, ws.max_row + 1):
        ws.cell(row=r, column=1).font = Font(bold=True)
    _autosize(ws)

    # References (one row each)
    ws = wb.create_sheet("References")
    headers = ["ID", "Type", "Audit status", "DOI (queried)", "DOI in ref?", "DOI source",
               "DOI exists", "HTTP", "Metadata match %", "Relevance %", "Relevance rationale",
               "Title verdict", "Authors verdict", "Author order OK", "Year verdict",
               "Journal verdict", "Volume verdict", "Issue verdict", "Pages verdict",
               "Flags", "Raw reference"]
    ws.append(headers); _style_header(ws, len(headers))

    def verdict_of(r, field):
        for m in r.get("field_matches", []):
            if m["field"] == field:
                return m["verdict"]
        return "N/A"

    for r in analysis["references"]:
        rel = r.get("relevance") if isinstance(r.get("relevance"), dict) else {}
        author_order = ""
        for m in r.get("field_matches", []):
            if m["field"] == "authors":
                author_order = "" if m.get("order_ok") is None else ("Yes" if m["order_ok"] else "No")
        ws.append([
            r["id"], r["type"], STATUS_LABEL.get(r["audit_status"], r["audit_status"]),
            r.get("queried_doi") or "", "Yes" if r.get("doi_in_reference") else "No",
            r.get("doi_source") or "", "" if r.get("doi_exists") is None else ("Yes" if r["doi_exists"] else "No"),
            r.get("http_status") or "", r.get("field_match_confidence"),
            rel.get("score"), rel.get("rationale", ""),
            verdict_of(r, "title"), verdict_of(r, "authors"), author_order, verdict_of(r, "year"),
            verdict_of(r, "container_title"), verdict_of(r, "volume"), verdict_of(r, "issue"),
            verdict_of(r, "pages"), "; ".join(r.get("flags", [])), r.get("raw_text", ""),
        ])
        row = ws.max_row
        sc = ws.cell(row=row, column=3)
        sc.fill = PatternFill("solid", fgColor=STATUS_FILL.get(r["audit_status"], "FFFFFF"))
        for col, field in [(12, None), (13, None), (15, None), (16, None), (17, None), (18, None), (19, None)]:
            v = ws.cell(row=row, column=col).value
            if v in VERDICT_FILL:
                ws.cell(row=row, column=col).fill = PatternFill("solid", fgColor=VERDICT_FILL[v])
    _autosize(ws)
    ws.column_dimensions["U"].width = 60
    ws.column_dimensions["K"].width = 45

    # FieldMatches (long form)
    ws = wb.create_sheet("FieldMatches")
    fh = ["Reference ID", "Field", "Verdict", "Score", "In reference", "Online (DOI)", "Note"]
    ws.append(fh); _style_header(ws, len(fh))
    for r in analysis["references"]:
        for m in r.get("field_matches", []):
            ws.append([r["id"], m["field"], m["verdict"], m.get("score"),
                       str(m.get("reference_value", ""))[:500], str(m.get("online_value", ""))[:500],
                       m.get("note", "")])
            v = m["verdict"]
            if v in VERDICT_FILL:
                ws.cell(row=ws.max_row, column=3).fill = PatternFill("solid", fgColor=VERDICT_FILL[v])
    _autosize(ws)

    # Issues
    ws = wb.create_sheet("Issues")
    ws.append(["Type", "Detail", "Reference IDs"]); _style_header(ws, 3)
    for iss in analysis.get("hygiene_issues", []):
        ws.append([iss["type"], iss["detail"], ", ".join(iss.get("ids", []))])
    _autosize(ws)

    # Unauditable
    ws = wb.create_sheet("Unauditable")
    uh = ["ID", "Type", "Authors", "Year", "Title", "Source/Journal", "Volume", "Issue", "Pages", "Reason"]
    ws.append(uh); _style_header(ws, len(uh))
    for r in analysis["references"]:
        if r["audit_status"] in ("unauditable_no_doi", "doi_not_found") and r.get("doi_source") != "discovered":
            p = r.get("parsed", {})
            auth = p.get("authors")
            auth = "; ".join(auth) if isinstance(auth, list) else (auth or "")
            reason = next((f for f in r.get("flags", []) if "auditable" in f.lower() or "DOI" in f), "")
            ws.append([r["id"], r["type"], auth, p.get("year", ""), p.get("title", ""),
                       p.get("container_title", ""), p.get("volume", ""), p.get("issue", ""),
                       p.get("pages", ""), reason])
    _autosize(ws)

    wb.save(out_path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("analysis")
    ap.add_argument("--outdir", default=".")
    ap.add_argument("--basename", default="reference_audit")
    args = ap.parse_args()

    with open(args.analysis, "r", encoding="utf-8") as f:
        analysis = json.load(f)

    os.makedirs(args.outdir, exist_ok=True)
    chart_dir = os.path.join(args.outdir, "_charts")
    charts = make_charts(analysis, chart_dir)

    docx_path = os.path.join(args.outdir, f"{args.basename}.docx")
    xlsx_path = os.path.join(args.outdir, f"{args.basename}.xlsx")
    build_docx(analysis, docx_path, charts)
    build_xlsx(analysis, xlsx_path)
    print(f"Wrote:\n  {docx_path}\n  {xlsx_path}")


if __name__ == "__main__":
    main()
