# Output templates

## Search log

| Search date | Source | Exact query | Filters | Results | Notes |
|---|---|---|---|---:|---|
| YYYY-MM-DD | PubMed | Copy exact query | Dates, humans, language | Number or `Not reported` | Coverage/access notes |

## Evidence matrix

| Citation | Design | Population and N | Exposure/intervention | Outcome measure | Main relevant finding | Limitation | DOI/PMID | Verification |
|---|---|---|---|---|---|---|---|---|

## SciSpace handoff

> Search for studies addressing: [research question]. Include [population], [intervention/exposure], [comparator if applicable], and [outcomes]. Limit to [dates/languages/study designs]. Create a table with citation, country, study design, sample size, population, intervention or exposure, comparator, outcome measurement method, follow-up, main finding, limitation, DOI, and PMID. Include only peer-reviewed journal articles; exclude preprints, conference abstracts, dissertations, editorials, letters, and grey literature. Do not include a paper unless a DOI, PMID, or other verifiable journal record is available.

## Verification table

| Proposed citation | Exists? | DOI | PMID | Supports the stated claim? | Verification source | Notes |
|---|---|---|---|---|---|---|

## Article summaries and gap analysis (closing section)

### Article summaries

1. **[First author, year]**: [What was studied, in whom, and the main finding, in 1–2 sentences.] *(abstract only, if applicable)*
2. ...

### Overall evidence summary

[One short paragraph or 3–5 bullets: agreement, disagreement, dominant designs, overall strength. Cite by matrix number, e.g. [1, 3].]

### Gap analysis

| # | Dimension | Gap identified | Evidence basis | Gap type | Confidence | Study that could address it |
|---|---|---|---|---|---|---|
| 1 | Population | e.g. No data in adults over 50 | All 6 studies [1–6] sampled ages 18–35 | Not found in this search | Preliminary | e.g. Cross-sectional study in adults 50+ using the same outcome measure |

Gap types: `Not found in this search` · `Thin evidence` · `Inconsistent findings` · `Methodologically weak`
Confidence: `Preliminary` (default) · `Supported`

### Top 3 priorities

1. [Gap]: [Why it is the most promising next study.]
2. ...
3. ...

> These gaps reflect only the articles retrieved in this search and should be confirmed with a broader or librarian-assisted search before being cited as gaps in the literature.

## Limitations statement

> This search used [sources] on [date]. [Unavailable sources] were not searched directly because the connector was not available in this conversation; ready-to-paste searches were provided instead. AI-assisted discovery can miss studies or mischaracterize findings. Citations and key claims should be checked against the original publications. Only peer-reviewed journal articles were included; journal publication was used as the indicator of peer review, which metadata cannot fully confirm. This output does not by itself constitute a systematic review.

