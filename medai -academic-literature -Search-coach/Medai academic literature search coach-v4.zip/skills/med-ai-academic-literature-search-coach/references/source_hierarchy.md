# Source hierarchy

Only peer-reviewed journal articles are included, whatever the source.

This skill does not use web search. Claude searches only the sources in "Searched directly." Every other source is a handoff: Claude writes the search, the user runs it and provides the results.

## Searched directly (when connected)

- PubMed: biomedical citations, indexed records, PMIDs, and metadata verification
- Consensus: focused scholarly questions and study discovery
- SciSpace: literature discovery, PDF interrogation, extraction, and comparison
- Files or exports the user uploads (PDFs, .nbib/.ris exports, PMID lists)

Treat Consensus and SciSpace as complementary discovery routes. Document which source found each study.

## Handoff only (Claude provides the search; the user runs it)

- Cochrane Library for systematic reviews and controlled-trial records
- ClinicalTrials.gov and other trial registries: only to locate a trial's journal publication; registry records are never cited
- Clinical guidelines from professional societies: only when published in a peer-reviewed journal
- Citation-mapping tools such as ResearchRabbit or Connected Papers

When one of these is relevant, give the user a ready-to-use search and ask them to paste or upload what they find. Verify anything they provide before using it.

Access to licensed full text or subscription databases may depend on the user's institution.

## Metadata verification

- PubMed record and PMID (through the PubMed connector)
- DOI and bibliographic fields as returned by Consensus or SciSpace
- Publisher or journal details in a file the user provides

Finding a valid bibliographic record confirms that a work exists. It does not confirm that the paper supports a particular claim.
